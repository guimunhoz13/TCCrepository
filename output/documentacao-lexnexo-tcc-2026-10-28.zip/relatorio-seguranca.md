# Relatório de Avaliação de Segurança — LexNexo

> **Contexto atualizado em 27/10/2026:** este arquivo preserva a avaliação
> histórica da revisão de setembro identificada abaixo. O estado atual do
> código, as novas correções, testes, cobertura e pendências estão no
> [relatório da auditoria completa](docs/testes/RELATORIO_VALIDACAO.md) e no
> [catálogo de achados](docs/testes/DEFEITOS_E_RISCOS.md). Não interpretar os
> 16 itens históricos como uma nova avaliação da revisão local atual. A
> autoria e a execução original no OpenCode continuam descritas abaixo.

## 1. Identificação e origem

| Campo | Informação |
|---|---|
| Projeto | LexNexo — ERP jurídico do TCC |
| Data da avaliação e revisão | 15/09/2026 |
| Revisão do código | `d30a306a38e0325ad470f2dc6cba5dabce79e70d`, branch `main` |
| Skill | `.opencode/skills/auditar-seguranca-lexnexo/SKILL.md` |
| Execução original | OpenCode, conforme informado pelo autor e pelo relatório original; modelo registrado originalmente como `opencode/big-pickle`. Os logs completos dessa sessão não foram examinados. |
| Revisão posterior | Codex: revisão dos 16 itens, conferência de fontes e testes isolados. Não corresponde a uma nova execução no OpenCode. |
| Alterações | Código da aplicação preservado. Foram produzidos este relatório, roteiro de apresentação, script de verificação e resultado dos testes. Os diretórios de mídia locais não foram examinados. |

## 2. Resumo executivo

O projeto possui controles de autenticação e filtros por escritório, mas contém falhas relevantes na autorização e na consistência dos relacionamentos. A prioridade é retirar a chave fixa de assinatura, proteger documentos, restringir a gestão de usuários e validar o escritório dos objetos relacionados.

Esta revisão contém **1 item crítico, 3 altos, 9 médios, 2 baixos e 1 informativo**. A contagem inclui recomendações e riscos condicionais; não representa 16 explorações comprovadas. As classificações são qualitativas, justificadas em cada item, e não são pontuações CVSS calculadas para o projeto.

Foram executados **50 testes em ambiente isolado: 39 existentes e 11 de reprodução, todos aprovados**. Nos testes de reprodução, aprovação significa que o comportamento descrito foi observado — inclusive falhas. **Não significa que o sistema passou por uma certificação de segurança.**

Os testes confirmaram, entre outros comportamentos, promoção indevida de perfil, troca de senha de terceiro, relacionamento com processo de outro escritório, leitura de dados de cliente por relatório, acesso com conta desativada, mídia sem autenticação e texto aceito como foto. Não houve acesso ao banco compartilhado nem uso de dados reais.

## 3. Escopo e metodologia

### 3.1 Material revisado

- Backend: `backend/core/settings.py`, `backend/core/urls.py`; views, serializers, modelos, mixins, validadores, integração com IA, e-mails, notícias e administração de `backend/advocacia/`; comando `criar_superadmin.py`; modelos, serializers, views, rotas, admin e testes de `backend/api/`.
- Testes: leitura dos 39 métodos de teste de `backend/advocacia/tests.py` e execução no ambiente descrito abaixo. `backend/api/tests.py` não contém casos implementados.
- Frontend: manifestos e lockfile, `frontend/next.config.mjs`, serviço de API, login comum e mestre, proteções de navegação de dashboard/painel mestre, layout, geração HTML de relatórios e notícias. Buscas adicionais por pontos de HTML dinâmico, armazenamento e URLs em `frontend/src/`.
- Configuração e histórico: README, `.gitignore`, workflow `.github/workflows/ci.yml`, revisão Git e restrições/relacionamentos relevantes das migrações. Isso não equivale a uma busca de segredos em todo o histórico Git.
- Fontes oficiais e código das versões das bibliotecas, identificados junto aos achados e na seção 7.

A conferência cobriu todos os itens deste relatório; não foi uma auditoria linha a linha de cada componente visual, biblioteca transitiva ou configuração externa.

### 3.2 Ambiente isolado e execução

Comando executado a partir da raiz do projeto:

```bash
backend/ambiente/bin/python seguranca/verificar_achados_isolado.py
```

O script lê somente configurações literais selecionadas por AST (análise sintática), sem importar `core.settings` ou executar `load_dotenv`. Usa SQLite em memória, mídia em diretório temporário, chave fictícia, e-mail em memória, chave de IA vazia e rede/DNS bloqueados. O teste usa cliente HTTP interno do Django, sem abrir servidor na rede. As migrações ocorreram apenas no banco descartável do teste.

Foi usado um hash rápido exclusivamente nesse processo para reduzir tempo; o teste não avalia resistência criptográfica das senhas. Essas diferenças em relação ao ambiente habitual — SQLite em vez de Postgres, configurações de teste e serviços externos desativados — limitam a extrapolação para produção.

Versões conferidas por metadados do ambiente `backend/ambiente`: Django **6.0.8**, DRF **3.17.1** e Simple JWT **5.5.1**. Manifesto e lockfile do frontend concordam em Next.js **16.2.6**, React e React DOM **19.2.4**; a instalação e a implantação do frontend não foram verificadas.

O log está em `seguranca/resultado-verificacao.txt`. Também foram usados `git status --short`, `git rev-parse HEAD`, `git branch --show-current`, buscas com `rg`, leitura com numeração de linhas e consultas às fontes oficiais. Não foram executados `npm audit`, `pip-audit`, build do frontend ou testes de carga.

### 3.3 Critério de evidência e gravidade

- **Reproduzido:** comportamento observado com dados fictícios no ambiente isolado.
- **Confirmado no código/advisory:** evidência estática ou versão afetada; não implica exploração em produção.
- **Condicional/recomendação:** depende de implantação, política ou outra vulnerabilidade ainda não demonstrada.

Crítica indica potencial comprometimento amplo de identidade; alta, quebra relevante de acesso ou isolamento; média, comprometimento mais condicionado ou abuso de recursos; baixa, impacto limitado/fortalecimento; informativa, ausência de falha demonstrada. A gravidade deve ser reavaliada conforme a implantação e os dados efetivamente usados.

## 4. Controles positivos e seus limites

| Controle observado | Evidência e limite |
|---|---|
| Hash nas senhas dos fluxos de API revisados | `backend/advocacia/serializers.py:139` e `backend/advocacia/views.py:131`; não prova que todo caminho administrativo aplica a mesma política. |
| Política de senha no cadastro e troca específica | `backend/advocacia/serializers.py:63`, `backend/advocacia/serializers.py:160`, `backend/advocacia/views.py:991`; o caminho de F03 a contorna. |
| Filtros de escritório em consultas principais | `backend/advocacia/mixins.py:59`; GET direto de processo de outro escritório foi negado, mas F04 compromete relações e dados derivados. |
| Estado ativo verificado no login | `backend/advocacia/views.py:103`; não substitui a verificação a cada sessão/requisição (F05). |
| Mestre exige cadastro ativo | `backend/advocacia/mixins.py:28`; essa consulta ocorre nas permissões mestre. |
| Validação de formato | `backend/advocacia/validators.py:81` verifica quantidade de dígitos de CPF; não verifica sua autenticidade. DNS MX e formato de e-mail não provam posse da caixa postal. |
| CORS restrito no código | `backend/core/settings.py:227`; restringe leitura entre origens no navegador, não substitui autorização da API. |
| Cabeçalho nosniff | SecurityMiddleware presente e cabeçalho observado no teste de mídia. |
| Contexto principal da IA filtrado e histórico com papéis restritos | `backend/advocacia/ia_service.py:31`, `backend/advocacia/ia_service.py:63` e `backend/advocacia/ia_service.py:161`; ainda depende de relações íntegras e limites de uso. |
| Escapamento de textos no relatório HTML do frontend | `frontend/src/utils/relatorio.js:12`; não é uma comprovação geral de ausência de XSS. |
| Notícias consultam URL fixa com timeout/cache | `backend/advocacia/noticias.py:35` e `backend/advocacia/noticias.py:80`; não foi identificada URL de busca controlada pelo usuário. |
| CI define Postgres descartável | `.github/workflows/ci.yml:17`; o arquivo foi revisado, mas nenhuma execução remota do CI foi validada nesta auditoria. |

## 5. Achados e recomendações

### F01 — Chave de assinatura JWT fixa no código

- **Severidade:** crítica
- **Evidência:** Confirmado por análise estática; falsificação com a chave real não executada.
- **Justificativa da gravidade:** Uma chave conhecida pode comprometer a identidade de usuários de todos os escritórios, inclusive a administração global.
- **Localização e análise:** `backend/core/settings.py:16` define uma chave literal; `backend/core/settings.py:237` configura autenticação JWT stateless sem substituir a chave de assinatura. `backend/advocacia/views.py:158` e `backend/advocacia/views.py:1324` emitem tokens. O padrão da biblioteca é HS256 com `settings.SECRET_KEY` ([Simple JWT 5.5.1](https://raw.githubusercontent.com/jazzband/djangorestframework-simplejwt/v5.5.1/rest_framework_simplejwt/settings.py)). O valor da chave não é reproduzido.
- **Condições:** O servidor precisa usar essa mesma chave e estar acessível. Também é necessário um identificador de usuário válido; para operações mestre, um `SuperAdmin` ativo.
- **Impacto e limites:** É possível produzir tokens assinados para identidades existentes. A autorização de perfil consulta o banco: mudar apenas a claim `tipo_usuario` não demonstra promoção a administrador. Para o painel mestre, o fluxo exige `is_master`, `superadmin_id` válido e as demais claims esperadas. Não foi demonstrado comprometimento de uma implantação real.
- **Recomendação:** Obter a chave por variável de ambiente, recusar inicialização sem ela e rotacionar a chave conhecida. Configurar explicitamente o segredo de assinatura e não versionar seu valor.
- **Validação da correção:** Em ambiente descartável, testar que a configuração sem segredo falha, tokens assinados pela chave anterior são rejeitados após rotação e tokens legítimos continuam funcionando. Nesta revisão, a chave dos testes foi inteiramente fictícia.

### F02 — Mídia acessível sem autenticação no modo DEBUG

- **Severidade:** alta
- **Evidência:** Confirmado no código e reproduzido localmente com arquivo fictício.
- **Justificativa da gravidade:** Documentos pessoais ou de processos podem ser lidos sem conferir usuário ou escritório, desde que o solicitante alcance a URL.
- **Localização e análise:** `backend/core/settings.py:19` fixa DEBUG verdadeiro; `backend/core/urls.py:37` adiciona as rotas de mídia. Os campos de documentos estão em `backend/advocacia/models.py:75`, `backend/advocacia/models.py:108` e `backend/advocacia/models.py:214`.
- **Condições:** O arquivo deve existir e o solicitante precisa alcançar o servidor e conhecer ou descobrir seu caminho. A configuração de rede e a publicação na internet não foram verificadas.
- **Impacto e limites:** No teste, um GET sem token a `/media/ficticio.txt` retornou 200. Isso comprova o comportamento local da rota, não que documentos reais estejam públicos na internet. DEBUG também aumenta a exposição de detalhes de erros.
- **Recomendação:** Configurar DEBUG e hosts por ambiente; fornecer arquivos por endpoint autorizado por escritório ou storage privado com acesso temporário. Apenas desligar DEBUG não protege uma configuração independente de Nginx ou bucket.
- **Validação da correção:** Testar acesso anônimo e de outro escritório negados, acesso do proprietário permitido e expiração de URLs temporárias, se usadas. Conferir também o serviço que entrega arquivos em produção.

### F03 — Gestão de usuários permite promoção de perfil e troca de senha de terceiros

- **Severidade:** alta
- **Evidência:** Confirmado no código e reproduzido em API local.
- **Justificativa da gravidade:** Um usuário já autenticado pode assumir privilégios administrativos dentro do próprio escritório. O alcance direto observado é o escritório, não a administração global.
- **Localização e análise:** `backend/advocacia/views.py:358` expõe `UsuarioViewSet` com `IsAuthenticated` e operações de escrita; `backend/advocacia/serializers.py:101` e `backend/advocacia/serializers.py:118` permitem senha e perfil; `backend/advocacia/serializers.py:143` salva os campos recebidos. As restrições de administrador existentes em outras views não se aplicam aqui.
- **Condições:** Usuário do escritório autenticado com token válido. O alvo da edição precisa pertencer ao mesmo escritório por causa do queryset.
- **Impacto e limites:** Um advogado alterou o próprio `tipo_usuario` para `admin` (200). Em outro passo, novamente como advogado, alterou a senha do administrador para uma senha de um caractere (200). Isso também demonstra que esse caminho contorna a política de senha aplicada ao endpoint específico de troca.
- **Recomendação:** Aplicar autorização por operação e campo; restringir gestão de terceiros a administradores. Para edição própria, permitir somente campos de perfil e separar troca de senha com verificação apropriada. Usar a mesma política de senha em todos os caminhos.
- **Validação da correção:** Testes negativos para autopromoção, mudança de senha/estado de terceiros e exclusão não autorizada; positivos para operações permitidas. Verificar que a política de senha também vale no gerenciamento administrativo.

### F04 — Relacionamentos permitem dados de outro escritório

- **Severidade:** alta
- **Evidência:** Confirmado no código; criação de movimentação e leitura de cliente via relatório reproduzidas.
- **Justificativa da gravidade:** A falha atravessa a separação entre escritórios e pode expor dados pessoais, além de permitir gravações indevidas.
- **Localização e análise:** `backend/advocacia/mixins.py:83` atribui escritório ao objeto, mas não valida seus relacionamentos. `backend/advocacia/serializers.py:300`, `backend/advocacia/serializers.py:338`, `backend/advocacia/serializers.py:364`, `backend/advocacia/serializers.py:391` e `backend/advocacia/serializers.py:495` expõem campos relacionais sem filtro de escritório. `backend/advocacia/views.py:614` valida duplicidade do número, não a pertença das relações. `backend/advocacia/views.py:1148` serializa o cliente ligado ao processo.
- **Condições:** Usuário autenticado informa ID existente de outra organização. Em contratos, `processo` é OneToOne (`backend/advocacia/models.py:271`), portanto a unicidade pode impedir algumas tentativas. Todas as demais validações do objeto continuam aplicáveis.
- **Impacto e limites:** O GET direto de processo B por usuário A foi negado (404), mas criar uma movimentação ligada a B retornou 201 e o título do processo. Também foi possível criar processo de A ligado a cliente B e obter o CPF fictício de B no relatório. Logo, filtrar a consulta principal não basta para proteger as relações. Contratos possuem escritório próprio e parcelas são filtradas pelo escritório do processo, criando inconsistência adicional quando essas relações divergem. Não se conclui acesso irrestrito a todo o banco.
- **Recomendação:** Restringir os querysets dos campos relacionais ao escritório da requisição e validar criação e alteração. Conferir também relações já gravadas, relatórios, IA e exportações; mudanças de código não corrigem automaticamente registros inconsistentes. A configuração do queryset deve ocorrer no contexto da requisição ([DRF: relações](https://www.django-rest-framework.org/api-guide/relations/)).
- **Validação da correção:** Cobrir criação e edição para cada relação, leitura direta e dados derivados, com usuários de A e B. As operações entre escritórios devem ser rejeitadas; as válidas no mesmo escritório devem continuar funcionando.

### F05 — Access token continua válido após desativação; refresh usa outro modelo de usuário

- **Severidade:** média
- **Evidência:** Access após desativação e divergência do refresh reproduzidos localmente.
- **Justificativa da gravidade:** A desativação não corta imediatamente uma sessão existente; a renovação tem comportamento inconsistente. O tempo efetivo depende da expiração e da configuração.
- **Localização e análise:** `backend/advocacia/mixins.py:23` busca `Usuario` sem verificar `ativo` nem `escritorio.ativo`; `backend/advocacia/views.py:998` troca senha sem revogar sessão. `backend/core/urls.py:25` usa `TokenRefreshView` padrão. O projeto define `Usuario` como `models.Model` (`backend/advocacia/models.py:56`) e não define `AUTH_USER_MODEL`. O serializer instalado consulta `get_user_model()` ([código Simple JWT 5.5.1](https://raw.githubusercontent.com/jazzband/djangorestframework-simplejwt/v5.5.1/rest_framework_simplejwt/serializers.py)).
- **Condições:** Access token previamente emitido, ainda não expirado. No refresh, o resultado também depende de existir um usuário Django com ID coincidente; os cadastros são distintos.
- **Impacto e limites:** Após desativar usuário e escritório, listar clientes com o access anterior retornou 200. No teste do serializer de refresh, a ausência do usuário Django gerou `DoesNotExist`; ao criar um usuário Django ativo com mesmo ID, a renovação foi aceita mesmo com o `Usuario` do LexNexo desativado. Não se deve afirmar que todo refresh funciona por um dia: os padrões são access de 5 minutos e refresh de 1 dia, mas a integração altera o resultado.
- **Recomendação:** Unificar o modelo de autenticação ou implementar refresh coerente com `Usuario` e `SuperAdmin`. Verificar estado do usuário/escritório nas requisições e revogar sessões conforme política. Blacklist exige integração com a emissão manual de tokens; apenas instalar o app não basta.
- **Validação da correção:** Testar desativação, troca de senha, expiração e refresh para usuário comum e mestre, incluindo IDs sem correspondência. Rejeitar sessões inválidas com resposta controlada, sem depender de usuário coincidente em outra tabela.

### F06 — Endpoint público revela existência e dados de contas

- **Severidade:** média
- **Evidência:** Confirmado e reproduzido sem autenticação.
- **Justificativa da gravidade:** Revela identidade e organização associadas a e-mails, facilitando enumeração e engenharia social.
- **Localização e análise:** `backend/advocacia/views.py:187` declara endpoint público; `backend/advocacia/views.py:216` devolve `existe`, `tipo_usuario`, `nome` e `escritorio_nome`. `backend/advocacia/views.py:103` diferencia estados da conta antes de conferir a senha.
- **Condições:** E-mail candidato e acesso de rede ao endpoint; não há throttle explícito na aplicação. Controles externos não foram verificados.
- **Impacto e limites:** O teste obteve nome de um usuário fictício sem token. Login com contas desativadas/bloqueadas também produz mensagens e estados diferentes. Não houve coleta de contas reais.
- **Recomendação:** Rever a necessidade da consulta pública e usar respostas genéricas que não revelem existência ou perfil. Retornar somente `existe` ainda permite enumeração. Uniformizar respostas e limitar tentativas.
- **Validação da correção:** Comparar corpo, código de resposta e comportamento para conta existente/inexistente e diferentes estados, sem divulgar nome ou escritório.

### F07 — Bloqueio por conta pode ser provocado por terceiro

- **Severidade:** média
- **Evidência:** Bloqueio após três erros reproduzido; ataque em escala não realizado.
- **Justificativa da gravidade:** Um terceiro pode impedir temporariamente o login de uma conta conhecida com poucas tentativas.
- **Localização e análise:** `backend/advocacia/views.py:131` incrementa contador e bloqueia por 15 minutos após três erros; `backend/core/settings.py:237` não define throttle. Os padrões do DRF não adicionam throttle automaticamente ([DRF 3.17.1](https://raw.githubusercontent.com/encode/django-rest-framework/3.17.1/rest_framework/settings.py)).
- **Condições:** E-mail válido, endpoint alcançável e ausência de mitigação externa suficiente.
- **Impacto e limites:** Três senhas erradas fizeram o login subsequente com senha correta retornar 403. O controle ajuda contra tentativas de senha, mas pode ser usado para negar acesso. Não foi testado um ataque distribuído ou concorrente.
- **Recomendação:** Combinar limites por origem e conta, atraso progressivo, recuperação e alertas. Projetar o controle para reduzir bloqueio induzido por terceiros. Throttle isolado por IP não resolve ataques distribuídos.
- **Validação da correção:** Validar limites com tentativas sequenciais, origens distintas e recuperação legítima, usando contas descartáveis. O assistente de IA é autenticado; não é um endpoint público.

### F08 — Uploads sem política efetiva e foto gravada sem validar imagem

- **Severidade:** média
- **Evidência:** Ausências de validação confirmadas; arquivo de texto como foto reproduzido.
- **Justificativa da gravidade:** Permite armazenar conteúdo inadequado e consumir espaço; riscos de conteúdo ativo dependem de como o arquivo é entregue e aberto.
- **Localização e análise:** `backend/advocacia/models.py:214` usa FileField para documentos. `backend/advocacia/views.py:961` atribui diretamente `request.FILES` à foto e `backend/advocacia/views.py:969` chama save. Esse caminho não usa o ImageField do serializer nem chama full_clean; save não executa essa validação automaticamente ([Django: instâncias](https://docs.djangoproject.com/en/6.0/ref/models/instances/#django.db.models.Model.full_clean)).
- **Condições:** Conta autenticada e acesso ao upload. Limites do proxy/storage e análise antimalware não foram verificados.
- **Impacto e limites:** Um arquivo de texto enviado como foto retornou 200. FileFields de documentos também não têm política explícita de conteúdo ou tamanho por arquivo. Isso não demonstra execução de código no servidor. Backend na porta 8000 e frontend na 3000 têm origens diferentes; não foi demonstrado roubo de tokens do frontend por mídia.
- **Recomendação:** Validar imagem no fluxo de atualização, definir tipos necessários, conferir conteúdo e tamanho por arquivo e limitar armazenamento. Entregar documentos com autorização e cabeçalhos adequados. FILE_UPLOAD_MAX_MEMORY_SIZE controla memória/disco e não é um limite de rejeição ([Django: configurações](https://docs.djangoproject.com/en/6.0/ref/settings/#file-upload-max-memory-size)).
- **Validação da correção:** Testar texto como foto, tipos não permitidos e arquivo acima do limite, além de um upload legítimo. Conferir download autorizado e cabeçalhos reais.

### F09 — DRF 3.17.1 afetado por advisory de limite de requisição

- **Severidade:** média
- **Evidência:** Versão declarada e instalada conferidas; advisory confirmado; exploração de consumo não executada.
- **Justificativa da gravidade:** O advisory é de gravidade moderada e trata consumo de recursos; não demonstra execução remota nem quebra de autenticação.
- **Localização e análise:** `backend/requirements.txt:4` fixa DRF 3.17.1 e essa versão foi encontrada no ambiente local. [GHSA-2m8g-3cmr-wg3w / CVE-2026-73228](https://github.com/encode/django-rest-framework/security/advisories/GHSA-2m8g-3cmr-wg3w) inclui versões até 3.17.1. A [release 3.17.2](https://github.com/encode/django-rest-framework/releases/tag/3.17.2) documenta a correção.
- **Condições:** Leitura de corpos JSON ou formulário urlencoded por request.data, sem limites externos suficientes. A relevância prática depende do servidor e do proxy.
- **Impacto e limites:** Possível contorno do limite Django ao analisar o corpo da requisição, com consumo adicional de memória/CPU. Não foram enviados corpos gigantes nem medidos efeitos em produção.
- **Recomendação:** Atualizar para uma versão compatível que contenha a correção, começando por 3.17.2 ou posterior, e testar limites de requisição na infraestrutura.
- **Validação da correção:** Confirmar versão instalada após atualização e executar teste controlado de rejeição acima de um limite pequeno no ambiente descartável. Não inferir que outras dependências estão seguras por essa atualização.

### F10 — Conteúdo de usuários interpolado em e-mails HTML

- **Severidade:** média
- **Evidência:** Confirmado por inspeção e teste da função geradora; nenhum e-mail enviado.
- **Justificativa da gravidade:** Permite alterar o conteúdo visual de mensagens atribuídas ao escritório, favorecendo links enganosos.
- **Localização e análise:** `backend/advocacia/emails.py:30`, `backend/advocacia/emails.py:50` e `backend/advocacia/emails.py:69` interpolam nomes e células em HTML sem escapamento. As views de envio exigem autenticação (`backend/advocacia/views.py:1187`).
- **Condições:** Um valor controlável precisa entrar no relatório e a mensagem precisa ser enviada e aberta em um cliente que renderize a marcação.
- **Impacto e limites:** O nome fictício `<b>FICTICIO</b>` permaneceu como tag no corpo gerado. Isso demonstra injeção de marcação, não execução de JavaScript em clientes de e-mail, que têm proteções próprias.
- **Recomendação:** Escapar valores não confiáveis com utilitários apropriados ou templates com autoescape; preservar somente a estrutura HTML criada pelo sistema.
- **Validação da correção:** Testar nomes, títulos e descrições contendo marcação e verificar que aparecem como texto. Conferir também que a mensagem legítima conserva sua formatação.

### F11 — IA envia dados pessoais e não tem limite explícito por usuário

- **Severidade:** média
- **Evidência:** Fluxo confirmado no código; riscos de abuso e manipulação de respostas não testados.
- **Justificativa da gravidade:** Combina envio de dados a fornecedor externo com possibilidade de uso excessivo de um recurso pago por conta autenticada.
- **Localização e análise:** `backend/advocacia/ia_service.py:36` inclui CPF, nome e contato do cliente selecionado; `backend/advocacia/ia_service.py:144` limita o histórico às últimas 20 mensagens e aos papéis user/assistant, sem limite de caracteres por mensagem. `backend/advocacia/ia_service.py:228` chama a API com limite de saída de 1500 tokens. `backend/advocacia/views.py:831` exige autenticação, sem quota explícita na view.
- **Condições:** Serviço configurado e usuário autenticado. Limites da conta do fornecedor e política organizacional não foram verificados; nenhuma chamada foi feita nesta revisão.
- **Impacto e limites:** Dados pessoais selecionados são incluídos na solicitação externa. A presença desse fluxo não prova infração legal. Conteúdo de usuários pode influenciar as respostas; não há demonstração de prompt injection bem-sucedida. Há filtro de papéis e limite de saída, mas isso não equivale a quota de chamadas ou limite total de entrada. Relações inconsistentes de F04 podem ampliar o contexto indevido.
- **Recomendação:** Minimizar campos enviados, documentar finalidade e condições de tratamento, limitar entrada e chamadas por usuário/escritório e definir orçamento. Separar instruções de conteúdo não confiável; não presumir que uma frase de segurança elimina prompt injection.
- **Validação da correção:** Com a chamada externa simulada, conferir os campos enviados, limites de entrada e quotas. Testes de manipulação devem medir respostas sem usar dados pessoais reais.

### F12 — Tokens acessíveis a JavaScript no navegador

- **Severidade:** média
- **Evidência:** Armazenamento confirmado; recomendação condicionada a comprometimento da origem.
- **Justificativa da gravidade:** Amplia o impacto de eventual XSS, mas não constitui, isoladamente, um XSS comprovado.
- **Localização e análise:** `frontend/src/components/forms/LoginForm.jsx:64` grava access e refresh no localStorage; `frontend/src/app/master/page.js:25` grava master_access; `frontend/src/services/api.js:19` lê o token. `frontend/next.config.mjs:2` não configura CSP; o cabeçalho efetivo da implantação não foi verificado.
- **Condições:** Código malicioso precisa executar com acesso à origem, ou o navegador precisa estar comprometido. Não foi encontrado e reproduzido um vetor de XSS completo nesta avaliação.
- **Impacto e limites:** Nessa condição, os tokens são acessíveis ao script. O script de tema de `frontend/src/app/layout.js:9` é estático e restringe o valor a light/dark; seu uso de dangerouslySetInnerHTML não prova vulnerabilidade. No relatório HTML há valores derivados não escapados, como status e contagens, mas seus produtores atuais restringem esses valores; não foi demonstrada entrada maliciosa nesses campos.
- **Recomendação:** Avaliar sessão com cookies HttpOnly/SameSite e proteção CSRF, ou outra estratégia que reduza a persistência e exposição; aplicar CSP compatível e expiração/revogação. Cookies não eliminam todas as consequências de XSS.
- **Validação da correção:** Verificar armazenamento e atributos de cookies/cabeçalhos no navegador após implementar a estratégia, incluindo logout. Tratar os testes de XSS como trabalho separado.

### F13 — CSV preserva valores interpretáveis como fórmula

- **Severidade:** baixa
- **Evidência:** Preservação do conteúdo reproduzida; execução em planilha não testada.
- **Justificativa da gravidade:** O efeito depende da abertura do arquivo e do comportamento da planilha, sem execução automática demonstrada no sistema.
- **Localização e análise:** `backend/advocacia/views.py:1262` e `backend/advocacia/views.py:1280` gravam textos no CSV sem neutralizar fórmulas.
- **Condições:** Um valor como `=1+1` é registrado e o CSV é aberto em software que o interpreta como fórmula.
- **Impacto e limites:** O teste confirmou `=1+1` no CSV de cliente fictício. Não foi demonstrada execução de comando do sistema operacional; o efeito pode variar entre programas e configurações.
- **Recomendação:** Neutralizar fórmulas nos campos textuais conforme a planilha de destino, considerando caracteres de controle. Aspas usadas pelo formato CSV não garantem que a célula seja tratada como texto.
- **Validação da correção:** Testar exportação e abertura/reabertura nas planilhas utilizadas, verificando que o valor seja texto literal e que dados comuns permaneçam legíveis.

### F14 — HTTPS e cookies de produção precisam de verificação

- **Severidade:** baixa
- **Evidência:** Recomendação de implantação; nosniff confirmado na resposta local.
- **Justificativa da gravidade:** A configuração de desenvolvimento não comprova falha em produção; o risco depende de proteções equivalentes na infraestrutura.
- **Localização e análise:** `backend/core/settings.py:55` inclui SecurityMiddleware; não configura explicitamente HSTS, redirecionamento HTTPS nem cookies Secure. Django já tem nosniff ativado e referrer policy same-origin por padrão ([configurações oficiais](https://docs.djangoproject.com/en/6.0/ref/settings/)).
- **Condições:** Implantação em rede, potencial acesso HTTP e ausência de proteção equivalente no proxy. Nenhum ambiente publicado foi inspecionado.
- **Impacto e limites:** O teste local confirmou `X-Content-Type-Options: nosniff`, corrigindo o falso positivo original. Sem HTTPS/cookies adequados na implantação, sessões administrativas podem ficar expostas a transporte inseguro.
- **Recomendação:** Configurar HTTPS, HSTS e cookies Secure conforme o ambiente e conferir o proxy confiável. Manter os controles já fornecidos pelo Django; avaliar CSP separadamente.
- **Validação da correção:** Inspecionar respostas, redirecionamentos e atributos de cookies do ambiente real, incluindo Django admin e frontend; não deduzir cabeçalhos apenas pela ausência de linhas no settings.

### F15 — Login mestre sem controle explícito de tentativas

- **Severidade:** média
- **Evidência:** Confirmado por análise do código; força bruta não executada.
- **Justificativa da gravidade:** O alvo tem privilégio global. A exploração ainda depende da senha, exposição do endpoint e controles externos, justificando prioridade maior que uma nota meramente informativa.
- **Localização e análise:** `backend/advocacia/views.py:1288` implementa login mestre sem contador ou throttle explícito. `backend/advocacia/management/commands/criar_superadmin.py:20` exige apenas seis caracteres. `backend/advocacia/views.py:1351` protege operações mestre com IsMasterUser.
- **Condições:** Endpoint alcançável e tentativas não bloqueadas externamente; sucesso de adivinhação depende da senha. A senha real não foi examinada.
- **Impacto e limites:** Possibilidade de tentativas repetidas contra uma credencial de alto privilégio. A verificação de SuperAdmin ativo existe e não foi tratada como ausente.
- **Recomendação:** Adicionar limitação de tentativas e recuperação apropriada, política consistente de senha e, conforme implantação, autenticação adicional ou acesso restrito ao painel.
- **Validação da correção:** Testar limitação, recuperação e login legítimo com contas fictícias, sem reproduzir um bloqueio facilmente induzido por terceiros como o de F07.

### F16 — App api legado não está incluído nas rotas atuais

- **Severidade:** informativa
- **Evidência:** Confirmado por leitura das rotas e do registro administrativo.
- **Justificativa da gravidade:** Não há vulnerabilidade de exposição demonstrada nesse app; é uma observação de manutenção.
- **Localização e análise:** `backend/api/views.py:8` define um ClienteViewSet global; `backend/core/urls.py:32` inclui advocacia.urls, não api.urls. `backend/api/admin.py` não registra o modelo. O app api continua em INSTALLED_APPS (`backend/core/settings.py:44`).
- **Condições:** A conclusão vale para o URLconf avaliado, sem inclusão adicional por configuração de implantação.
- **Impacto e limites:** Não foi identificada rota ativa para esse ViewSet. O app ainda participa do projeto e das migrações; chamá-lo de código totalmente inativo seria impreciso.
- **Recomendação:** Documentar a finalidade do app legado e avaliar dependências antes de eventual remoção, sem apagar modelos ou migrações indiscriminadamente.
- **Validação da correção:** Conferir rotas e consumidores antes de alterar ou remover o app. Não contabilizar essa nota como falha explorável.

## 6. Resultados dos testes

| Teste de reprodução | Resultado observado |
|---|---|
| F02/F14 — mídia e cabeçalho | Arquivo fictício sem token: 200; nosniff presente. |
| F03 — perfil/senha | Autopromoção e troca de senha de terceiro aceitas: 200. |
| F04 — movimentação | GET direto do processo B: 404; gravação relacionada por A: 201 e título exposto. |
| F04 — relatório | Processo A associado a cliente B; relatório devolveu CPF fictício de B. |
| F05 — desativação | Access vigente continuou aceito após desativar usuário e escritório. |
| F05 — refresh | Falha sem auth.User correspondente; renovação com ID coincidente ativo, mesmo com Usuario desativado. |
| F06 — consulta pública | Nome fictício revelado sem token. |
| F07 — bloqueio | Após três erros, senha correta recebeu 403. |
| F08 — upload | Texto aceito no campo foto: 200. |
| F10 — e-mail | Tag fictícia preservada como HTML; sem envio. |
| F13 — CSV | Fórmula inofensiva `=1+1` preservada; sem abrir planilha. |

Resultado final: **50 testes, zero falhas no executor**. São 39 testes existentes e 11 de reprodução. Estes últimos documentam o estado atual; depois de corrigir a aplicação, suas expectativas devem ser convertidas em testes de rejeição da operação indevida. Nenhum token, documento ou conta real foi utilizado.

## 7. Dependências e fontes verificadas

A análise de dependências foi pontual, não exaustiva. Uma versão corrigida para um advisory não significa ausência de outras falhas.

| Componente | Verificação |
|---|---|
| DRF 3.17.1 | Afetado pelo advisory de tamanho de requisição (F09). Release 3.17.2 confirma correção. |
| AdminRenderer do DRF | O [GHSA-g47c-3xmw-q6m2](https://github.com/encode/django-rest-framework/security/advisories/GHSA-g47c-3xmw-q6m2) é real, mas esse renderer não está habilitado no código/configuração analisados; os padrões são JSONRenderer e BrowsableAPIRenderer. Não foi contado como falha aplicável. |
| Django 6.0.8 | As [notas da versão](https://docs.djangoproject.com/en/6.0/releases/6.0.8/) documentam correções das CVEs 2026-15307, 2026-15337, 2026-15830 e 2026-15920. Não se verificou todo advisory posterior ou biblioteca transitiva. |
| Next.js 16.2.6 | O [advisory oficial GHSA-26hh-7cqf-hhc6](https://github.com/vercel/next.js/security/advisories/GHSA-26hh-7cqf-hhc6), CVE-2026-45109, lista 16.2.6 como corrigida para esse problema específico. Manifesto e lockfile declaram essa versão. Isso não certifica React Server Components nem todo o frontend. |
| Simple JWT 5.5.1 | Configurações e código de autenticação/refresh da versão foram conferidos; F05 é uma falha de integração do projeto, que deve ser analisada mesmo com biblioteca atualizada. |

Outras referências técnicas utilizadas:

- [Simple JWT 5.5.1: autenticação stateless](https://raw.githubusercontent.com/jazzband/djangorestframework-simplejwt/v5.5.1/rest_framework_simplejwt/authentication.py).
- [Django: configurações e padrões](https://docs.djangoproject.com/en/6.0/ref/settings/).
- [Django: validação de instâncias](https://docs.djangoproject.com/en/6.0/ref/models/instances/).
- [DRF: campos relacionais](https://www.django-rest-framework.org/api-guide/relations/).
- [OpenCode: descoberta e carregamento de Skills](https://opencode.ai/docs/skills/).

## 8. Cobertura e pendências

| Área | Cobertura desta revisão |
|---|---|
| Autenticação e autorização | Código revisado; testes pontuais de perfil, sessão, enumeração e bloqueio. |
| Separação entre escritórios | Código de relações revisado; reprodução em movimentação/processo/relatório. Nem toda combinação de relação/método foi executada. |
| Uploads e mídia | Código revisado; foto inválida e arquivo anônimo reproduzidos. Sem antimalware ou teste de carga. |
| IA e notícias | Fluxos revisados; chamadas externas não executadas. |
| E-mail e CSV | Geração local testada; clientes de e-mail e planilhas não executados. |
| Frontend | Revisão dirigida dos fluxos indicados; sem build, auditoria visual ou exploração no navegador. |
| Dependências | Bibliotecas principais e advisories citados; sem varredura integral/transitiva. |
| Implantação | Não verificados rede, proxy, HTTPS efetivo, storage, backups ou logs de produção. |
| Dados e segredos reais | `.env` e arquivos de mídia não abertos; sem conexão com Supabase. |
| Execução original no OpenCode | Informada pelo autor e pelo relatório; histórico completo e carregamento da Skill não comprovados por logs nesta revisão. |

## 9. Plano de ação

| Prioridade | Itens | Ação | Esforço estimado |
|---|---|---|---|
| Antes de publicar/usar dados reais | F01 | Remover e rotacionar segredo fixo. | Baixo a médio; exige coordenar configuração e sessões. |
| Antes de publicar/usar dados reais | F02 | Autorizar downloads e definir storage privado. | Médio; envolve infraestrutura. |
| Antes de publicar/usar dados reais | F03/F04 | Corrigir permissões e relações; examinar inconsistências já gravadas. | Médio a alto. |
| Curto prazo | F05/F15 | Corrigir integração de sessão/refresh e proteção do login mestre. | Médio. |
| Curto prazo | F06/F07/F09 | Reduzir enumeração, melhorar limites e atualizar DRF. | Baixo a médio. |
| Em seguida | F08/F10/F11 | Validar arquivos, escapar e-mails e limitar/minimizar uso da IA. | Médio. |
| Conforme implantação | F12/F13/F14 | Rever sessão no navegador, neutralizar CSV e conferir HTTPS/cookies. | Médio. |
| Manutenção | F16 | Documentar dependências do app legado. | Baixo. |

Esforços são estimativas qualitativas; não representam prazo medido. A revisão alterou documentação e adicionou verificações isoladas, **não implementou as correções de segurança na aplicação**.

## 10. Conclusão

O relatório revisado sustenta falhas reais e reproduzíveis, especialmente na gestão de usuários e nos relacionamentos entre escritórios. Há controles positivos, mas eles não cobrem todos os caminhos. A chave fixa e a entrega de documentos também exigem atenção antes de uma implantação com dados reais.

A análise original ocorreu, segundo o registro fornecido, no OpenCode. A revisão posterior no Codex conferiu os achados e acrescentou evidências isoladas, com origem explicitada. Não se atribuem ao OpenCode os testes feitos nesta revisão.

A conclusão é uma avaliação técnica do estado identificado do código, com limitações documentadas. Não é certificação de segurança, declaração de conformidade legal, garantia de ausência de outras falhas ou de aprovação acadêmica. Para a entrega, este arquivo acompanha o `SKILL.md`; eventuais requisitos adicionais do material de aula precisam ser conferidos pelo aluno.
