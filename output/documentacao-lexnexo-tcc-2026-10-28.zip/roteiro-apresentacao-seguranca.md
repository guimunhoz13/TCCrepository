# Roteiro de apresentação — Skill de segurança do LexNexo

> Atualização de 27/10/2026: para apresentar a situação atual do sistema,
> acompanhe este roteiro histórico com o
> [relatório da auditoria completa](docs/testes/RELATORIO_VALIDACAO.md),
> o [registro prático preservado](docs/testes/TESTES_PRATICOS.md) e o
> [adendo acadêmico](docs/tcc/AUDITORIA-2026-10-27.md). A auditoria nova foi
> executada no Codex; isso não cria evidência de uma execução nova no OpenCode.

Tempo sugerido: **5 a 7 minutos**. Material de apoio para estudar; os dois arquivos pedidos no enunciado são a Skill e o relatório.

## 1. O que entregar e o que ainda conferir

| Pedido visível na atividade | Situação |
|---|---|
| Criar uma Skill em Markdown para avaliar a segurança do TCC | Arquivo `.opencode/skills/auditar-seguranca-lexnexo/SKILL.md` criado, com objetivo, procedimento, limites e formato de saída. |
| Aplicar a Skill no OpenCode | Você informou que executou no OpenCode; o relatório original registra isso. Esta revisão não examinou o histórico completo do aplicativo. |
| Gerar relatório `.md` | `relatorio-seguranca.md` revisado, com evidências e origem dos testes. |
| Enviar Skill e relatório individualmente no AVA | Anexar os dois arquivos; o envio não foi realizado por esta revisão. |
| Seguir o formato visto anteriormente em aula | O material anterior não foi fornecido. Comparar com ele antes de enviar. |

**Não prometa “100% seguro” ou “100% de certeza da nota”.** O trabalho pode ser apresentado como uma avaliação técnica revisada, limitada ao escopo descrito.

Se precisar mostrar que a Skill foi usada no OpenCode, abra a conversa original e localize o carregamento da Skill ou a leitura do SKILL.md e a geração do relatório. Mostrar essa conversa é evidência útil; a imagem da atividade não exige explicitamente screenshot. Não invente um registro se ele não aparecer.

O diretório `.opencode` começa com ponto e fica oculto no gerenciador de arquivos. No Linux, Ctrl+H costuma exibir pastas ocultas.

## 2. Fala de abertura — cerca de 40 segundos

> O meu projeto é o LexNexo, um sistema para escritórios de advocacia. Ele armazena informações de clientes, processos e documentos. Por isso, a avaliação de segurança priorizou quem pode acessar cada informação e a separação dos dados entre escritórios.
>
> Para a atividade, preparei uma Skill em Markdown com apoio de IA e a apliquei no OpenCode. O resultado foi um relatório com evidências no código e recomendações. Depois, fiz uma revisão assistida pelo Codex, que corrigiu inconsistências e acrescentou testes locais isolados.

Use essa fala se ela corresponde ao que você realmente fez. A geração inicial e a revisão posterior estão identificadas separadamente no relatório.

## 3. Explicar Skill, agente e harness — cerca de 50 segundos

> A Skill é um arquivo reutilizável que orienta a IA: o que avaliar, quais limites respeitar e como escrever o resultado. Ela não treina um novo modelo e não é uma correção automática do sistema.
>
> O harness é o ambiente que permite ao agente trabalhar: conversar, ler arquivos e usar ferramentas. Nesta atividade, esse papel foi do OpenCode. O modelo é quem interpreta o pedido; o OpenCode organiza a execução; a Skill fornece instruções específicas; o relatório é o resultado.

Mostre o início do `SKILL.md`:

- `name`: identifica a Skill.
- `description`: descreve quando usá-la.
- Corpo do arquivo: objetivo, etapas, restrições e formato do relatório.

A [documentação do OpenCode](https://opencode.ai/docs/skills/) descreve a descoberta de Skills em `.opencode/skills/<nome>/SKILL.md` e o carregamento pela ferramenta `skill`.

## 4. Mostrar o método — cerca de 50 segundos

> A Skill pediu análise de autenticação, permissões, relacionamentos entre escritórios, uploads, configurações, dependências e integrações. Para cada achado, exigiu localização no código, impacto, condições necessárias e recomendação.
>
> A primeira análise foi estática: leitura do código. Na revisão, foram feitos testes dinâmicos controlados, usando SQLite em memória, dados fictícios e rede bloqueada. Não foi acessado o banco compartilhado do Supabase.

Explique a diferença:

- **Análise estática:** ler o código sem executar os fluxos da aplicação.
- **Teste dinâmico:** executar um fluxo com entradas controladas e observar a resposta.
- **Limitação:** SQLite, configurações de teste e serviços simulados não representam toda a implantação real.

## 5. Apresentar três exemplos — cerca de 2 minutos

### Exemplo 1 — Uma pessoa logada não pode fazer tudo (F03)

> O sistema verificava se a pessoa estava autenticada, mas o endpoint de usuários não restringia alguns campos de administrador. No teste, um advogado fictício conseguiu mudar o próprio perfil para admin e alterar a senha de outro usuário do mesmo escritório.
>
> A correção proposta é verificar a permissão de cada operação e campo, além de estar logado.

Para mostrar a evidência, abra `backend/advocacia/views.py:358` e `backend/advocacia/serializers.py:99`. Não precisa executar a operação ao vivo.

**Conceito:** autenticação é “quem você é”; autorização é “o que você pode fazer”.

### Exemplo 2 — Filtrar a lista não protege todos os relacionamentos (F04)

> O escritório A não conseguia abrir diretamente o processo de B. Isso era um controle positivo. Mas conseguia criar uma movimentação apontando para o processo de B, e a resposta devolvia o título.
>
> Em outro teste, foi criado um processo de A ligado a um cliente de B. O relatório desse processo revelou o CPF fictício do cliente de B. A proposta é validar também se cada relacionamento pertence ao escritório correto.

Mostre `backend/advocacia/mixins.py:83`, `backend/advocacia/serializers.py:300` e a linha correspondente na seção 6 do relatório.

**Exemplo verbal:** “Não basta conferir a pasta do escritório; é preciso conferir se o documento ligado a ela também pertence àquele escritório.”

### Exemplo 3 — A IA também apontou um falso positivo (F14)

> O relatório inicial afirmava que faltava o cabeçalho nosniff porque ele não aparecia explicitamente no arquivo de configuração. A revisão consultou o padrão do Django e testou uma resposta. O cabeçalho já estava presente.
>
> Isso mostra que uma resposta da IA precisa ser conferida. A ausência de uma linha de configuração não significa que o controle não exista.

Mostre a seção F14 e o teste de mídia/cabeçalho em `seguranca/resultado-verificacao.txt`.

Evite mostrar a chave SECRET_KEY real em tela. Se mencionar F01, explique apenas que a chave de assinatura estava fixa e que sua rotação foi recomendada.

## 6. Explicar o resultado dos testes — cerca de 40 segundos

> Foram executados 50 testes: 39 já existentes e 11 de reprodução da auditoria. Todos passaram no ambiente isolado. Nos testes de reprodução, passar significa que conseguimos observar o comportamento investigado, inclusive uma falha. Portanto, não significa que o sistema está seguro.
>
> O relatório contém 16 itens, mas inclui recomendações e uma nota informativa. Eles não são 16 ataques comprovados em produção.

Se perguntarem a contagem de gravidade: **1 crítico, 3 altos, 9 médios, 2 baixos e 1 informativo**. São classificações qualitativas justificadas, não uma pontuação matemática de segurança.

## 7. Fechamento — cerca de 30 segundos

> A principal contribuição da Skill foi organizar a avaliação e exigir evidências. O trabalho identificou falhas reais, reconheceu controles existentes e definiu prioridades de correção. Também mostrou a importância de revisar o que a IA produz.
>
> O relatório é uma avaliação com limites claros. Nesta atividade foram revisados o relatório e os testes; as correções da aplicação ainda precisam ser implementadas.

## 8. Perguntas que o professor pode fazer

### “Por que criar uma Skill em vez de só escrever um prompt?”

Porque as instruções ficam organizadas em um arquivo reutilizável, com nome e descrição que permitem sua descoberta pelo agente. Um prompt também orienta uma execução; a Skill facilita repetir o procedimento em outra sessão.

### “O que o OpenCode fez e o que o Codex fez?”

O OpenCode foi usado na execução inicial que gerou o relatório. O Codex ajudou a preparar a Skill e depois revisou o relatório e executou verificações isoladas. Não foram atribuídas ao OpenCode as ações posteriores do Codex.

### “Como comprova que a Skill foi carregada?”

Pela conversa original no OpenCode, mostrando o carregamento pela ferramenta skill ou a leitura do arquivo, se esse registro estiver disponível. A existência do relatório, sozinha, não comprova a sequência de ferramentas utilizada.

### “Você corrigiu as falhas do sistema?”

Não. Corrigi o relatório e acrescentei testes para conferir os achados. As recomendações de segurança ainda precisam ser implementadas na aplicação.

### “Como há testes aprovados e falhas de segurança ao mesmo tempo?”

Os testes existentes verificam os comportamentos para os quais foram escritos. Os novos testes verificam se uma falha pode ser reproduzida. Depois de corrigir o sistema, as expectativas desses testes devem exigir que as operações indevidas sejam rejeitadas.

### “Por que não usou o Supabase?”

Para manter a auditoria isolada dos dados compartilhados. O teste usou banco em memória, arquivos temporários e dados fictícios. Isso também torna o resultado mais fácil de repetir.

### “O sistema está vulnerável na internet?”

O código apresenta falhas, mas esta revisão não verificou uma implantação na internet. Exposição externa depende de rede, hosts, proxy e storage. Não foi feito teste em produção.

### “Validar CPF e e-mail garante segurança?”

Não. Os validadores verificam alguns formatos; não garantem identidade, posse do e-mail nem autorização sobre um registro. Cada controle resolve uma parte do problema.

### “Por que o token pode funcionar depois de desativar a conta?”

Porque o access token é validado e o código busca o usuário sem verificar seu estado ativo em cada acesso. O login verifica esse estado, mas uma sessão já emitida percorre outro caminho.

### “E o problema de renovação?”

O LexNexo usa um modelo Usuario próprio. A renovação padrão consulta o usuário Django. No teste, isso produziu falha sem registro correspondente e aceitação com ID coincidente. Por isso o relatório não afirma que toda sessão sempre dura um dia.

### “A IA inventou tudo?”

Não. Alguns achados foram reproduzidos. Outros precisaram de correção, como a contagem e o cabeçalho nosniff. Revisar significa separar evidência, hipótese e recomendação.

### “Qual é a primeira correção?”

Rotacionar a chave fixa e corrigir os controles de acesso: permissões de usuários, relacionamentos entre escritórios e entrega de documentos. O plano de ação explica a ordem e as dependências.

## 9. Sequência de demonstração sem depender de uma nova execução

1. Abrir a conversa original do OpenCode, se disponível, para explicar a aplicação da Skill.
2. Mostrar `SKILL.md`: nome, objetivo e exigência de evidências.
3. Abrir o relatório e mostrar F03 ou F04.
4. Mostrar a seção 6 e o resultado dos testes isolados.
5. Fechar com o plano de ação e as limitações.

Uma nova execução ao vivo pode produzir resultados diferentes ou demorar. Para apresentar, o relatório e as evidências já salvas são suficientes para explicar a metodologia, salvo orientação diferente do professor.

## 10. Frase curta para memorizar

> “A Skill organizou a avaliação, o OpenCode executou a análise inicial e a revisão conferiu as evidências. Foram identificadas falhas reais, mas o trabalho não é uma certificação de segurança.”
