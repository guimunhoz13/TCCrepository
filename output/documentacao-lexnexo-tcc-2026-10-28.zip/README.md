# LexNexo — ERP Jurídico

<p align="center">
  <img src="assets/branding/lexnexo-logo.svg" alt="LexNexo" width="360">
</p>

> **O nexo entre gestão e Direito.**

[![CI](https://github.com/guimunhoz13/TCCrepository/actions/workflows/ci.yml/badge.svg)](https://github.com/guimunhoz13/TCCrepository/actions/workflows/ci.yml)

Sistema de gestão para escritórios de advocacia (ERP jurídico): cadastro de
clientes, advogados e processos, agenda com prazos e audiências, upload e
organização de documentos, geração de relatórios (com envio por e-mail e
WhatsApp), notícias do mundo jurídico e criminal, e um assistente com IA —
tudo isolado por escritório (multi-tenant).

Projeto acadêmico (TCC) desenvolvido em dupla, para a disciplina de
Tecnologia em Desenvolvimento de Sistemas.

Os arquivos oficiais da marca e as regras de aplicação ficam em
[`assets/branding`](assets/branding/README.md).

## Stack

- **Backend**: Django 6 + Django REST Framework, autenticação via JWT
  (`djangorestframework_simplejwt`), Postgres (hospedado no
  [Supabase](https://supabase.com), banco compartilhado pela dupla).
- **Frontend**: Next.js 16 (App Router) + React 19, CSS puro (design system
  próprio).

## Estrutura

```
backend/    API Django (advocacia/, core/; o app api antigo foi removido)
frontend/   Aplicação Next.js (src/app, src/components, src/services)
docs/testes/ Plano, inventário, matriz, resultados e evidências da auditoria
```

## Rodando localmente

### Backend

```bash
cd backend
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt coverage
# Primeiro prepare um PostgreSQL LOCAL exclusivo na porta 55439,
# com banco lexnexo_auditoria e usuário igual ao usuário do sistema.
python manage.py migrate --settings=core.settings_auditoria
python manage.py runserver --settings=core.settings_auditoria
```

Para executar toda a auditoria em um cluster PostgreSQL novo, use
[`scripts/auditoria-local.sh`](scripts/auditoria-local.sh); as instruções e
variáveis estão no [guia de reprodução](docs/testes/EVIDENCIAS.md).
`core.settings_auditoria` ignora o `.env`, força banco em loopback, usa mídia
temporária, e-mail em memória e desativa chaves de IA, DataJud e push.
Nunca use esse módulo para publicar a aplicação.

O ambiente compartilhado de desenvolvimento pode usar Supabase. Suas
credenciais ficam em `backend/.env` (não versionado; veja
`backend/.env.example`). Antes de usar os settings padrão e executar qualquer
escrita ou migração, confirme o destino do banco e a autorização. Peça a string de conexão pra quem já tiver
criado o projeto no Supabase, ou crie um novo em
[supabase.com](https://supabase.com) → New Project → região
**"South America (São Paulo)"** (uma região distante adiciona latência
perceptível em toda consulta) → Connect → "Session pooler" (não o
"Transaction pooler" — veja o comentário em `.env.example` sobre
`CONN_MAX_AGE`), e compartilhe os dados com a dupla.

### Frontend

```bash
cd frontend
npm ci
npm run dev
```

## Imagem Docker do frontend

O [`frontend/Dockerfile`](frontend/Dockerfile) compila o Next.js em três etapas
e executa o servidor standalone com um usuário sem privilégios. Para construir
a imagem em um ambiente com Docker ativo:

```bash
cd frontend
docker build -t lexnexo-frontend .
docker run --rm -p 3000:3000 lexnexo-frontend
```

`NEXT_PUBLIC_API_URL` é incorporada ao frontend na compilação. Quando a API
estiver em outro endereço, informe `--build-arg NEXT_PUBLIC_API_URL=...` no
`docker build`. O [`frontend/Dockerfile.labex`](frontend/Dockerfile.labex) usa
uma exportação estática previamente gerada para ambientes de laboratório sem
acesso ao Docker Hub.

## Segurança em produção

Para publicar um piloto com dados fictícios na Vercel (site), Render (API) e
Supabase (banco e arquivos privados), veja [o guia do piloto](docs/deploy-piloto.md).

- Sem `DEBUG=True` o backend sobe em modo produção: exige `SECRET_KEY`
  (recusa subir sem ela), redireciona para HTTPS, liga HSTS e marca os
  cookies como seguros. No `.env` local mantenha `DEBUG=True`.
- O CI roda `manage.py check --deploy --fail-level WARNING` e falha em
  qualquer aviso de segurança de deploy.
- O servidor Next.js envia CSP, `X-Frame-Options`, `Referrer-Policy` e
  `Permissions-Policy` (`frontend/next.config.mjs`). Na exportação estática,
  esses cabeçalhos devem ser configurados no servidor web; a configuração
  usada no LabEx fica em `frontend/nginx.labex.conf`.
- Fotos de usuários e clientes são servidas por uma rota autenticada da API.
  Não publique `backend/media/` diretamente no servidor web: documentos e
  comprovantes são disponibilizados apenas pelas rotas de download com
  controle de acesso.
- O refresh token é trocado a cada renovação e o anterior é revogado.
- O assistente de IA tem limite próprio (20 chamadas/minuto por usuário) e
  aceita mensagens de até 4000 caracteres.

## Tarefas agendadas

Os lembretes de agenda e o resumo semanal são enviados por um comando que
precisa ser executado uma vez por dia por um agendador externo (não há
Celery no projeto):

```bash
cd backend && python manage.py enviar_lembretes
```

O comando é idempotente por canal e etapa — cada aviso fica registrado em
`NotificacaoEnviada`, então rodar duas vezes no mesmo dia não reenvia nada.
E-mail e push são tentados de forma independente: a falha de um canal não
impede o outro. Prazos fatais recebem reforços dois dias antes, um dia antes
e no próprio dia; os avisos anteriores são substituídos no aparelho para não
empilhar cartões repetidos. Opções:

- `--dry-run`: mostra o que seria enviado, sem enviar e sem registrar.
- `--resumo-semanal`: força o resumo fora da segunda-feira (útil para demonstrar).

O que ele envia depende das preferências de cada usuário (Configurações →
Notificações): `lembrete_audiencia` e `antecedencia_audiencia` para
compromissos, `lembrete_prazo` para prazos, e `resumo_semanal` para o
resumo das segundas. Dentro do sistema, o sino continua funcionando mesmo
sem esses canais: ele reúne itens vencidos e os próximos sete dias, com
destaque textual para prazo fatal, vencimento e processo relacionado.

Há também a consulta automática ao DataJud, que percorre os processos
ativos, importa os andamentos novos e avisa quem optou por receber:

```bash
cd backend && python manage.py sincronizar_datajud
```

Ela é um comando separado de propósito: cada processo é uma chamada HTTP a
um serviço externo, então a rotina é lenta e sujeita a falhas que não devem
atrapalhar o envio dos lembretes. Opções: `--dry-run`, `--limite N`
(máximo de processos por execução, padrão 50) e `--intervalo-horas N`
(não reconsulta um processo visto há menos de N horas, padrão 12).
Processos concluídos ou arquivados não são consultados, e a rotina exige
`DATAJUD_API_KEY` configurada.

As intimações publicadas no Diário de Justiça Eletrônico Nacional (DJEN)
são buscadas pela OAB de cada advogado (no formato `123456/SP`). Cada uma é
ligada ao processo cadastrado, o prazo é lido do texto (ou estimado em 5
dias úteis, CPC art. 218 § 3º) e lançado na agenda:

```bash
cd backend && python manage.py buscar_intimacoes   # --dias N (padrão 7)
```

Exemplo de agendamento no cron — intimações às 6h, lembretes às 7h,
sincronização às 5h:

```cron
0 6 * * * cd /caminho/para/backend && /caminho/para/python manage.py buscar_intimacoes
0 7 * * * cd /caminho/para/backend && /caminho/para/python manage.py enviar_lembretes
0 5 * * * cd /caminho/para/backend && /caminho/para/python manage.py sincronizar_datajud
```

Sem SMTP configurado (`EMAIL_HOST_USER`/`EMAIL_HOST_PASSWORD`), o Django cai
no backend de console e apenas imprime os e-mails — veja `backend/.env.example`.

## Cálculo de prazos e feriados locais

A calculadora da agenda e as intimações do DJEN contam os prazos em dias
úteis. Elas pulam os fins de semana, os feriados nacionais (inclusive os
móveis, calculados a partir da Páscoa) e o recesso forense de 20/12 a 20/01.
Feriados municipais e estaduais e suspensões de expediente variam por comarca
e são cadastrados pelo escritório em **Agenda › Feriados locais**. Um feriado
pode valer só naquela data ou repetir todo ano. O sistema não traz uma lista
pronta, porque quem define o calendário forense é cada tribunal. A calculadora
mostra quais feriados locais mudaram a contagem.

## Planos

Todo escritório novo entra no plano **Gratuito**, sem pagamento nem cartão. Os
planos pagos ampliam os limites e trazem as automações e a IA:

| | Gratuito | Básico (R$ 79/mês) | Profissional (R$ 199/mês) |
|---|---|---|---|
| Usuários ativos | até 3 | até 10 | ilimitados |
| Processos ativos | até 30 | até 300 | ilimitados |
| Clientes, agenda, tarefas, documentos, DataJud (consulta), PIX, 2FA, LGPD | sim | sim | sim |
| Intimações do DJEN e sincronização automática do DataJud | — | sim | sim |
| Assistente de IA e mensagens ao cliente escritas pela IA | — | — | sim |

O catálogo fica em `backend/advocacia/planos.py`, e a API aplica os limites.
Passar do limite só impede criar mais; nada é apagado. Processos concluídos ou
arquivados não contam. Um plano pago com validade vencida vale como Gratuito
até ser renovado. O plano e a validade de cada escritório são definidos pelo
administrador da plataforma no painel mestre (`/master`). A cobrança online
ainda não está ligada a um meio de pagamento: o botão "Quero este plano"
abre um e-mail para `CONTATO_COMERCIAL` (variável de ambiente do backend).

## Dados de demonstração

```bash
cd backend && python manage.py popular_demo --settings=core.settings_auditoria
```

Use `--recriar` somente no banco descartável e quando desejar remover os dados
anteriores da demonstração. Não use essa opção na conta dos testes práticos
preservados nem em banco compartilhado.

Cria o escritório "Silva & Sabino Advocacia (demonstração)" com clientes,
processos (um em segredo de justiça), agenda, tarefas, contrato com parcelas
e chave PIX. Todos entram com a senha `Demo@1234`: `admin@`, `advogada@`,
`estagiario@`, `financeiro@` e `secretaria@demo.lexnexo.app` — um de cada
perfil de acesso.

## Testes de ponta a ponta (E2E)

Com a API isolada (`core.settings_auditoria`, porta 8000) e o front (porta
3000) rodando sobre dados sintéticos de `popular_demo` no banco exclusivo:

```bash
cd frontend && npm run e2e
```

O Playwright usa o sistema como uma pessoa usaria — login, cadastro de
cliente, ficha do processo, perfis de acesso, Kanban, PIX, agenda .ics e
celular — e checa acessibilidade (WCAG AA) com axe. No CI, o job
"E2E (Playwright)" sobe Postgres, API e front sozinho.

## Documentação da API

Com o back-end rodando, a documentação interativa (OpenAPI 3, gerada com
drf-spectacular a partir das próprias views e serializers) fica em:

- `http://localhost:8000/api/docs/` — Swagger UI (clique em **Authorize** e
  cole o `access` devolvido por `POST /api/login/` para testar as rotas);
- `http://localhost:8000/api/redoc/` — ReDoc;
- `http://localhost:8000/api/schema/` — o arquivo OpenAPI.

Para esconder a documentação em produção, defina `API_DOCS_PUBLICAS=False`.

## Testes

```bash
# Backend (Django)
cd backend && python manage.py test --settings=core.settings_auditoria

# Frontend (Jest)
cd frontend && npm test
```

## Auditoria completa de 27/10/2026

O parecer e os limites da execução estão no
[relatório de validação](docs/testes/RELATORIO_VALIDACAO.md). Consulte também
o [plano](docs/testes/PLANO_DE_TESTES.md), a
[matriz de requisitos](docs/testes/MATRIZ_RASTREABILIDADE.md), o
[inventário de endpoints e casos](docs/testes/INVENTARIO_E_CASOS.md), o
[catálogo de defeitos e riscos](docs/testes/DEFEITOS_E_RISCOS.md), as
[evidências e comandos](docs/testes/EVIDENCIAS.md), o
[guia de arquitetura, API e uso](docs/testes/ARQUITETURA_API_E_MANUAL.md) e os
[testes práticos preservados na conta autorizada](docs/testes/TESTES_PRATICOS.md).

O [relatório técnico atual, versão 1.8](docs/tcc/RT-TDS-2026-39_v1.8.docx),
incorpora os resultados e apresenta 34 capturas atualizadas da interface
LexNexo em 28/10/2026, com sumário revisado e identificação das simulações.

As correções estão na cópia local. A navegação na aplicação publicada não
equivale à implantação dessas correções. A cobertura de linhas do frontend
permanece abaixo da meta; e-mail/push entregues, IA paga, configurações remotas,
backup/restauração e avaliação com usuários têm limitações documentadas.

## CI

A cada push/PR para `main`, o GitHub Actions ([`.github/workflows/ci.yml`](.github/workflows/ci.yml))
roda automaticamente:

- **Backend**: instala as dependências, roda os testes contra um Postgres
  de serviço (efêmero, não é o Supabase do projeto) e valida o projeto
  (`manage.py check`).
- **Frontend**: instala as dependências, roda os testes (Jest) e faz o
  build de produção (`next build`).
